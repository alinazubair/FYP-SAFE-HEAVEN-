<?php
include 'header.php';
include 'connect.php';

// Fetch property submission requests from the database
try {
    $stmt = $conn->prepare("SELECT * FROM properties_data ORDER BY submission_time DESC");
    $stmt->execute();
    $propertyRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error fetching property requests: " . $e->getMessage();
}
?>

<div class="nk-content">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between g-3">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">User Verification Approval</h3>
                        </div>
                    </div>
                </div>

                <div class="nk-block">
                    <div class="card">
                        <div class="card-inner">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Property Owner</th>
                                            <th>Property ID</th>
                                            <th>Submitted</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($propertyRequests as $request) : ?>
                                            <tr>
                                                <td><?php echo $request['owner_name']; ?></td>
                                                <td><?php echo $request['property_code']; ?></td>
                                                <td><?php echo $request['submission_time']; ?></td>
                                                <td><?php echo $request['status']; ?></td>
                                                <td>
                                                    <!-- Approve and Reject buttons with form submission -->
                                                    <form method="post" action="html/lms/approve_reject.php">
                                                        <input type="hidden" name="property_code" value="<?php echo $request['property_code']; ?>">
                                                        <button type="submit" name="approve" class="btn btn-success btn-sm">Approve</button>
                                                        <button type="submit" name="reject" class="btn btn-danger btn-sm">Reject</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap, text-center">
                            <div class="nk-footer-copyright"> &copy; 2023 Safe Heaven. All rights reserved</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->


            </div>
        </div>
    </div>
</div>

<?php ?>
