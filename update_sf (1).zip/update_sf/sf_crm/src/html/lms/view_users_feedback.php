              
              <?php
              
              include 'header.php';
              ?>
              <!-- main header @e -->
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-block-head nk-block-head-sm">
                                <div class="nk-block-between">
                                    <div class="nk-block-head-content">
                                        <h3 class="nk-block-title page-title">Users Feedbacks</h3>
                                    
                                    </div><!-- .nk-block-head-content -->
                                    <div class="nk-block-head-content">
                                        <div class="toggle-wrap nk-block-tools-toggle">
                                            <a href="#" class="btn btn-icon btn-trigger toggle-expand me-n1" data-target="more-options"><em class="icon ni ni-more-v"></em></a>
                                            <div class="toggle-expand-content" data-content="more-options">
                                                <ul class="nk-block-tools g-3">
                                                    
                                                    <!-- <li class="nk-block-tools-opt">
                                                        <a href="html/components/forms/add-property-form.html" class="btn btn-icon btn-primary d-md-none"><em class="icon ni ni-plus"></em></a>
                                                        <a href="html/components/forms/add-property-form.html" class="btn btn-primary d-none d-md-inline-flex"><em class="icon ni ni-plus"></em><span>Add</span></a>
                                                    </li> -->
                                                </ul>
                                            </div>
                                        </div>
                                    </div>.nk-block-head-content
                                </div><!-- .nk-block-between -->
                            </div><!-- .nk-block-head -->
                            
                           
                            



                            <div class="nk-block nk-block-lg">
                   
                                <div class="card card-bordered card-preview">
                                    <div class="card-inner">
                                    <table id="demoid" class="datatable-init-export  table" data-export-title="Export">


                                   
                                    <!-- <div class="nk-block-head-content"><a href="#"
                                                class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em
                                                    class="icon ni ni-download-cloud"></em><span>Export</span></a><a
                                                href="#"
                                                class="btn btn-icon btn-outline-light bg-white d-inline-flex d-sm-none"><em
                                                    class="icon ni ni-download-cloud"></em></a></div> -->





                                                    <thead>
                                                        <tr>
                                               
                                                         
                                                        <th></th>
                                                            
                                                            <th>Username</th>
                                                  
                                                            <th>Email</th>
                                                            <th>Feedback</th>
                                                            
                                                          
                                                        
                                                            <?php
                                                        
                                                        if($_SESSION['role']=='admin'){
                                                        
                                                        ?>
                                                        <th>View Feedbacks</th>
                                                        <?php
                                                        
                                                             }
                                                        
                                                        ?>
                                                            
                                              
  
                                                            <th>View Feedback</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                    




                                                      <tr>
                                             
                                                             <td><?php echo $print['username']; ?></td>
                                                             
                                                            
                                                           

                                                             <td> <?php echo $print['email']; ?></td>
                                                             <td><?php echo $print['ac_feedback']; ?></td>
                                                            
                                                         


                                                            <?php
                                                            if($_SESSION['role']=='admin'){
                                                        ?>
                                                        
                                                  










                                                            
                                                            
                                                            <?php
                                                        }
                                                            ?>


                                                        
                                                           
                                                            <td>
    <div class="dropdown">
        <a class="dropdown-toggle btn btn-icon btn-light" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
        <div class="dropdown-menu dropdown-menu-end">
            <ul class="link-list-opt">
                <!-- Replace the link with the property code -->
                <!-- Replace the link with the property code -->
                <li><a href="html/lms/view_property.php?property_id=<?php echo $print['id']; ?>"><em class="icon ni ni-eye"></em><span>View Detail</span></a></li>

                
            </ul>
        </div>
    </div>
</td>


      
                                                        

                                                        </tr>


                                                        <?php


                


        

?>
                                                        
                                                    </tbody>
                                                </table>
                                    </div>
                                </div><!-- .card-preview -->
                            </div> <!-- nk-block -->
                    </div>
                </div>
                <!-- content @e -->




                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap, text-center">
                            <div class="nk-footer-copyright"> &copy; 2023 Safe Heaven. All rights reserved</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    
    <!-- JavaScript -->
    <script src="./assets/js/bundle.js?ver=3.0.3"></script>
    <script src="./assets/js/scripts.js?ver=3.0.3"></script><script src="html/lms/datetime.js"></script>
    <script src="./assets/js/libs/datatable-btns.js"></script>

   
   
</body>

</html>