<?php
// admin_response.php

include 'header.php';

// Database connection details
$servername = "your_database_host"; // Replace with your database host
$username = "your_database_username"; // Replace with your database username
$password = "your_database_password"; // Replace with your database password
$dbname = "properties_data"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch feedback data from the database
$feedbackData = array(); // Initialize an array to store feedback data

// Assuming you have a 'feedback' table in your database
$sql = "SELECT * FROM feedback";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch data from each row
    while ($row = $result->fetch_assoc()) {
        $feedbackData[] = $row;
    }
}

// Close the database connection
$conn->close();
?>

<!-- Rest of the code remains the same -->


<!-- Admin response content -->
<div class="nk-content">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block">
                    <div class="card">
                        <div class="card-inner">
                            <h5 class="card-title">User Feedback Response</h5>
                            <p>Response to the feedback received from the user.</p>

                            <!-- Display user feedback details -->
                            <?php foreach ($feedbackData as $feedback) : ?>
                                <div class="row g-3 align-center">
                                    <div class="col-lg-5">
                                        <div class="form-group">
                                            <label class="form-label">User's Name</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-7">
                                        <p><?php echo $feedback['name']; ?></p>
                                    </div>
                                </div>

                                <div class="row g-3 align-center">
                                    <div class="col-lg-5">
                                        <div class="form-group">
                                            <label class="form-label">User's Email</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-7">
                                        <p><?php echo $feedback['email']; ?></p>
                                    </div>
                                </div>

                                <div class="row g-3 align-center">
                                    <div class="col-lg-5">
                                        <div class="form-group">
                                            <label class="form-label">User's Message</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-7">
                                        <p><?php echo $feedback['message']; ?></p>
                                    </div>
                                </div>

                                <!-- Add more fields as needed -->

                                <!-- Add your response form here if you want to reply to the user -->

                            <?php endforeach; ?>
                        </div><!-- .card-inner -->
                    </div><!-- .card -->
                </div><!-- .nk-block -->
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
