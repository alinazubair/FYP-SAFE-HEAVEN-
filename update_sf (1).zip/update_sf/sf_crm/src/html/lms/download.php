<?php
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['document'])) {
    $documentType = $_GET['document'];

    // Fetch document details from the database based on the document type
    try {
        $stmt = $conn->prepare("SELECT document_path FROM properties_data WHERE document_type = :document_type");
        $stmt->bindParam(':document_type', $documentType);
        $stmt->execute();
        $document = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($document) {
            // Set the appropriate headers for file download
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($document['document_path']) . '"');
            readfile($document['document_path']);
            exit();
        } else {
            echo "Document not found.";
        }
    } catch (PDOException $e) {
        echo "Error fetching document details: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
?>
