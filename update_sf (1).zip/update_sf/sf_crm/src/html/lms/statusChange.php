<?php
	//connection


	include 'connect.php';
 

 
	if(isset($_GET['action'])){
		$action = $_GET['action'];
	}
 
	
 
	if($action == 'change_hold'){
		$id = $_POST['id'];
		$output = array();
		$sql = "UPDATE  all_vouchers_data set authorized = 'authorized' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'transition updat e successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}







    
	if($action == 'change_authorized'){
		$id = $_POST['id'];
		$output = array();
		$sql = "UPDATE  all_vouchers_data set authorized = 'hold' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'transition update successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}




	
	if($action == 'change_paid'){
		$id = $_POST['id'];
		$output = array();
		$sql = "UPDATE  ticket_entry set deliver_status = 'Refund' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'Ticket is Refund successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}











	
	if($action == 'cs_approved'){
		$id = $_POST['id'];
		$output = array();
		$sql = "UPDATE  costsheet_data set status = 'approved' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'Cost Sheet is Approved';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}





	
	
	if($action == 'cs_pending'){
		$id = $_POST['id'];
		$output = array();
		$sql = "UPDATE  costsheet_data set status = 'pending' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'Cost Sheet is Pending ';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}




	
	if($action == 'change_refund'){
		$id = $_POST['id'];
		$output = array();
		$sql = "UPDATE  ticket_entry set deliver_status = 'Paid' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'Ticket is Paid successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}



	
	if($action == 'change_access'){
		$id = $_POST['id'];

		$output = array();
		$sql = "UPDATE  empolyee set ac_all_entry = 'show' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'hogya successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}



	
	if($action == 'change_access_band'){
		$id = $_POST['id'];

		$output = array();
		$sql = "UPDATE  empolyee set ac_all_entry = 'hide' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'hide hogya successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}





	if($action == 'invoice_paid'){
		$id = $_POST['id'];
		$output = array();
		$sql = "UPDATE  properties_data set status = 'paid' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'transition update successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}




	if($action == 'invoice_unpaid'){
		$id = $_POST['id'];
		$output = array();
		$sql = "UPDATE  properties_data set status = 'unpaid' WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'transition update successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}

    ?>
 