              
              <?php
              
              include 'header.php';
              ?>
              <!-- main header @e -->
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-block-head nk-block-head-sm">
                                <div class="nk-block-between">
                                    <div class="nk-block-head-content">
                                        <h3 class="nk-block-title page-title">Properties Records</h3>
                                    
                                    </div><!-- .nk-block-head-content -->
                                    <div class="nk-block-head-content">
                                        <div class="toggle-wrap nk-block-tools-toggle">
                                            <a href="#" class="btn btn-icon btn-trigger toggle-expand me-n1" data-target="more-options"><em class="icon ni ni-more-v"></em></a>
                                            <div class="toggle-expand-content" data-content="more-options">
                                                <ul class="nk-block-tools g-3">
                                                    
                                                    <!-- <li class="nk-block-tools-opt">
                                                        <a href="html/components/forms/add-property-form.html" class="btn btn-icon btn-primary d-md-none"><em class="icon ni ni-plus"></em></a>
                                                        <a href="html/components/forms/add-property-form.html" class="btn btn-primary d-none d-md-inline-flex"><em class="icon ni ni-plus"></em><span>Add</span></a>
                                                    </li> -->
                                                </ul>
                                            </div>
                                        </div>
                                    </div><!-- .nk-block-head-content -->
                                </div><!-- .nk-block-between -->
                            </div><!-- .nk-block-head -->
                            
                           
                            <?php if ($_SESSION['role'] == 'admin') { ?>
                            <div class="d-flex justify-content-end">


                                 

                           
<a class="btn btn-info d-none d-md-inline-flex"  href="html/lms/add_property.php"  ><em class="icon ni ni-plus"></em><span>Add Property </span></a>
</div>

<?php }?>



                            <div class="nk-block nk-block-lg">
                   
                                <div class="card card-bordered card-preview">
                                    <div class="card-inner">
                                    <table id="demoid" class="datatable-init-export  table" data-export-title="Export">


                                   
                                    <!-- <div class="nk-block-head-content"><a href="#"
                                                class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em
                                                    class="icon ni ni-download-cloud"></em><span>Export</span></a><a
                                                href="#"
                                                class="btn btn-icon btn-outline-light bg-white d-inline-flex d-sm-none"><em
                                                    class="icon ni ni-download-cloud"></em></a></div> -->





                                                    <thead>
                                                        <tr>
                                               
                                                         
                                                        <th>Property ID</th>
                                                            
                                                            <th>Owner Name</th>
                                                  
                                                            <th>Property Type</th>
                                                            <th>Feedback</th>
                                                            <th>Date</th>
                                                          
                                                        
                                                            <?php
                                                        
                                                        if($_SESSION['role']=='admin'){
                                                        
                                                        ?>
                                                        <th>Status </th>
                                                        <?php
                                                        
                                                             }
                                                        
                                                        ?>
                                                            
                                                            
                                                        
                                        

  
                                                            <th>Action</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                    <?php

include 'connect.php';



try {
    $stmt = $conn->prepare("SELECT * FROM properties_data");
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_BOTH);
} catch (PDOException $e) {
    echo "Error fetching property details: " . $e->getMessage();
    die();
}



$pb_user = $_SESSION['email'];
if($_SESSION['role']=='admin'){
    $stmt = $conn->prepare("select * from properties_data" );
}else{



    $stmt = $conn->prepare("select * from properties_data where user = '$pb_user' and status = 'paid' " );

}


  $stmt->execute();


$result = $stmt->fetchAll(PDO::FETCH_BOTH);





?>


<?php
if(count($result)){

    foreach($result as $print){
        


        

?>













                                                      <tr>
                                             
                                                             <td><?php echo $print['property_code']; ?></td>
                                                             
                                                            
                                                           

                                                             <td> <?php echo $print['owner_name']; ?></td>
                                                             <td><?php echo $print['property_type']; ?></td>
                                                            <td>

                                                            <a class="btn btn-icon btn-trigger" data-bs-toggle="modal" href="#feed<?php echo $print['id']?>"><em class="icon ni ni-comments text-primary" style="font-size:30px;"></em></a>






















                                                            <div class="modal fade" id="feed<?php echo $print['id']?>">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross"></em></a>
                <form method="post" action="html/lms/submit.php">
    <div class="modal-body">
        <h5 class="title mb-4">Enter Your Feedback</h5>

        <div class="form-group">
            <label class="form-label" for="owner-id">Owner ID</label>
            <input type="text" readonly name="property_code" class="form-control mainagent" id="owner-id" placeholder="" value="<?php echo htmlspecialchars($print['id']); ?>">
        </div>

        <div class="form-group">
            <label class="form-label" for="property-description">Enter Feedback</label>
            <textarea class="form-control" name="property_description" aria-label="With textarea"><?php echo htmlspecialchars($print['feedback']); ?></textarea>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </div>
</form>

            </div>
        </div>
    </div>







                                                            </td>
                                                            <td><?php echo date('d-m-Y ' , strtotime($print['date']));?></td>
                                                         


                                                            <?php
                                                            if($_SESSION['role']=='admin'){
                                                        ?>
                                                        
                                                  





                                                        <td>
                                                        
                                                        <?php
                                                        
                                                        if($print['status']== "paid"){
                                                        
                                                        ?>
                                                          <a    class=" btn change_authorized " data-id='<?php echo $print['id'];?>'>   <span class="dot bg-success d-sm-none"></span>
                                               <span class="badge badge-sm badge-dot has-bg bg-success d-none d-sm-inline-flex  "     >Approved</span></a>
<?php
                                                        }else{
                                                            ?>








<a    class=" btn change_hold " data-id='<?php echo $print['id'];?>'> <span class="dot bg-danger d-sm-none"></span>
                                                <span class="badge badge-sm badge-dot has-bg bg-danger d-none d-sm-inline-flex"  >Rejected</span></a>






       <?php                                                     
                                                        }
?>

                                                        </td>




















                                                   




































                                                            
                                                            
                                                            <?php
                                                        }
                                                            ?>


                                                        
                                                           
                                                            <td>
    <div class="dropdown">
        <a class="dropdown-toggle btn btn-icon btn-light" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
        <div class="dropdown-menu dropdown-menu-end">
            <ul class="link-list-opt">
                <!-- Replace the link with the property code -->
                <!-- Replace the link with the property code -->
                <li><a href="html/lms/view_property.php?property_id=<?php echo $print['property_code']; ?>"><em class="icon ni ni-eye"></em><span>View Detail</span></a></li>

                <?php if ($_SESSION['role'] == 'admin') { ?>
                <!-- Other options if needed -->
                <li><a class="btn delete_product" data-id='<?php echo $print['id']; ?>'><em class="icon ni ni-activity-alt"></em><span>Delete</span></a></li>
                <?php }?>
            </ul>
        </div>
    </div>
</td>


      
                                                        

                                                        </tr>


                                                        <?php


}}
        


        

?>
                                                        
                                                    </tbody>
                                                </table>
                                    </div>
                                </div><!-- .card-preview -->
                            </div> <!-- nk-block -->
                    </div>
                </div>
                <!-- content @e -->




                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap, text-center">
                            <div class="nk-footer-copyright"> &copy; 2023 Safe Heaven. All rights reserved</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    
    <!-- JavaScript -->
    <script src="./assets/js/bundle.js?ver=3.0.3"></script>
    <script src="./assets/js/scripts.js?ver=3.0.3"></script><script src="html/lms/datetime.js"></script>
    <script src="./assets/js/libs/datatable-btns.js"></script>


    <script type="text/javascript">


function run(){


    location.reload(true); 
}

				$(document).ready(function(){
			

					$(document).on('click', '.delete_product', function(){
						var id = $(this).data('id');

						swal.fire({
							title: 'Are you sure?',
							text: "You won't be able to revert this!",
							icon: 'warning',
							showCancelButton: true,
							confirmButtonColor: '#3085d6',
							cancelButtonColor: '#d33',
							confirmButtonText: 'Yes, delete it!',
						}).then((result) => {
							if (result.value){
								$.ajax({
									url: 'html/lms/delete.php?action=properties_delete',
									type: 'POST',
									data: 'id='+id,
									dataType: 'json'
								})
								.done(function(response){
									swal.fire('Deleted!', response.message, response.status);
                                    run();
							
								})
								.fail(function(){
									swal.fire('Oops...', 'Something went wrong with ajax !', 'error');
								});
							}

						})

					});
				});
















                


$(document).ready(function(){
			


            $(document).on('click', '.change_hold', function(){
                var id = $(this).data('id');

      

                swal.fire({
                    title: 'Are you sure?',
                    text: "Payment is Paid!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1EE0AC',
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'NO',
                    confirmButtonText: 'APPROVED',
                }).then((result) => {
                    if (result.value){
                        $.ajax({
                            url: 'html/lms/statusChange.php?action=invoice_paid',
                            type: 'POST',
                            data: 'id='+id,
                            dataType: 'json'
                        })
                        .done(function(response){
                            swal.fire('Updated!', response.message, response.status);
                            run();
                    
                        })
                        .fail(function(){
                            swal.fire('Oops...', 'Something went wrong with ajax !', 'error');
                        });
                    }

                })

            });
        });





        

$(document).ready(function(){
			


            $(document).on('click', '.change_authorized', function(){
                var id = $(this).data('id');

      

                swal.fire({
                    title: 'Are you sure?',
                    text: "Payment is unpaid!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'NO',
                    confirmButtonText: 'REJECTED',
                }).then((result) => {
                    if (result.value){
                        $.ajax({
                            url: 'html/lms/statusChange.php?action=invoice_unpaid',
                            type: 'POST',
                            data: 'id='+id,
                            dataType: 'json'
                        })
                        .done(function(response){
                            swal.fire('Updated!', response.message, response.status);
                            run();
                    
                        })
                        .fail(function(){
                            swal.fire('Oops...', 'Something went wrong with ajax !', 'error');
                        });
                    }

                })

            });
        });




                </script>
   
   
</body>

</html>