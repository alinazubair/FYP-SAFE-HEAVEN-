<?php



include 'header.php';
?>
                <!-- main header @e -->
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between g-3">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title page-title">Add Property</h3>

      
                                        </div>
                                    </div>
                                </div>

                                      
                               
                                <div class="nk-block">
                                <form method="post" action="html/lms/submit.php" enctype="multipart/form-data">
    <div class="card">
        <div class="card-inner">
            <div class="row gy-4">
                <div class="col-md-12">
                    <h5 class="bg-dark text-white p-1 text-center">Owner Details</h5>
                </div>

                <!-- Owner ID -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="owner-id">Owner ID</label>
                        <input type="text" readonly name="property_code" class="form-control mainagent" id="owner-id" placeholder="" value="<?php echo rand(10000, 99999); ?>">
                    </div>
                    
                    <!-- <div><input type="text" readonly name="user" class="form-control mainagent" id="" placeholder="" value="<?php echo $_SESSION['email']; ?>"></div> -->
                </div>

                <!-- Owner Name -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="owner-name">Owner Name</label>
                        <input type="text" class="form-control" id="owner-name" name="lname" placeholder="Owner Name">
                    </div>
                </div>

                <!-- Phone Number -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="phone-no">Phone Number</label>
                        <input type="text" class="form-control" id="phone-no" name="phone" placeholder="Phone Number">
                    </div>
                </div>

                <!-- CNIC -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="cnic">CNIC</label>
                        <input type="text" class="form-control" id="cnic" name="cnic" placeholder="CNIC">
                    </div>
                </div>

                <!-- Property Details -->
                <div class="col-md-12">
                    <h5 class="bg-dark text-white p-1 text-center">Property Details</h5>
                </div>

                <!-- Property Type -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="property-type">Property Type</label>
                        <select name="property_type" class="form-select js-select2" id="property-type">
                            <option value="Residential">Residential</option>
                            <option value="Commercial">Commercial</option>
                            <option value="Industrial">Industrial</option>
                            <option value="Vacant">Vacant</option>
                        </select>
                    </div>
                </div>

                <!-- City -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="city">City</label>
                        <select name="city" class="form-select js-select2" id="city">
                            <option value="Karachi">Karachi</option>
                            <option value="Lahore">Lahore</option>
                            <option value="Islamabad">Islamabad</option>
                            <option value="Rawalpindi">Rawalpindi</option>
                            <option value="Faisalabad">Faisalabad</option>
                            <option value="Multan">Multan</option>
                            <option value="Gujranwala">Gujranwala</option>
                            <option value="Peshawar">Peshawar</option>
                            <option value="Quetta">Quetta</option>
                            <option value="Sialkot">Sialkot</option>
                            <option value="Bahawalpur">Bahawalpur</option>
                            <option value="Sargodha">Sargodha</option>
                            <option value="Larkana">Larkana</option>
                            <option value="Gujrat">Gujrat</option>
                           
                        </select>
                    </div>
                </div>

                <!-- Property Address -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="property-address">Property Address</label>
                        <input type="text" name="address" class="form-control" id="property-address" value="">
                    </div>
                </div>

                <!-- Property Size -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="property-size">Property Size</label>
                        <input type="text" name="property_size" class="form-control" id="property-size" value="">
                    </div>
                </div>

                

                <!-- Year of Construction -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="construction-year">Year of Construction</label>
                        <input type="date" class="form-control" id="construction-year" name="year_of_construction" placeholder="Year of Construction">
                    </div>
                </div>


                <!-- Property Description -->
                <div class="col-md-12">
                    <div class="form-group">
                        <label class="form-label" for="property-description">Property Description</label>
                        <textarea class="form-control" name="property_description" aria-label="With textarea"></textarea>
                    </div>
                </div>


                <!-- Property Features -->
                <div class="col-md-12">
                    <h5 class="bg-dark text-white p-1 text-center">Property Features</h5>
                </div>

                <!-- Bedrooms -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="bedrooms">No of Bedrooms</label>
                        <input type="number" class="form-control" id="bedrooms" name="bedrooms" placeholder="Enter No of Bedrooms">
                    </div>
                </div>

                <!-- Bathrooms -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="bathrooms">No of Bathrooms</label>
                        <input type="number" class="form-control" id="bathrooms" name="bathrooms" placeholder="Enter No of Bathrooms">
                    </div>
                </div>

                <!-- Amenities -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label" for="amenities">Amenities</label>
                        <input type="text" class="form-control" id="amenities" name="amenities" placeholder="e.g swimming pool, parking area, garden etc.">
                    </div>
                </div>

                <!-- Upload Document -->
                <div class="col-md-12">
                    <h5 class="bg-dark text-white p-1 text-center">Upload Documents (Jpg, png etc)</h5>
                </div>






                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label" for="email">Sale Deed</label>


                                                     
                                               
                                            <div class="gallery card ">
                                                
                                            
                                           


                                                    <img class="w-100 rounded-top " id="imagePreview1" alt="" style="height:250px;width:200px;" src="html/lms/properties_documents/blank.jpg">
                                        
                                              
                                            
                                           
                                                </div>
                                       

                                                        <input type="file" id="imageInput1" accept="image/*"  class=" pt-4 form-control " name="sale_deed" >
                                                    </div>
                                                </div>

                                                


                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label" for="email">Title Deed</label>


                                                     
                                               
                                            <div class="gallery card ">
                                                
                                            
                                           


                                                    <img class="w-100 rounded-top " id="imagePreview2" alt="" style="height:250px;width:200px;" src="html/lms/properties_documents/blank.jpg">
                                        
                                              
                                            
                                           
                                                </div>
                                       

                                                        <input type="file" id="imageInput2" accept="image/*"  class=" pt-4 form-control " name="title_deed" >
                                                    </div>
                                                </div>                 






                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label" for="email">NOC</label>


                                                     
                                               
                                            <div class="gallery card ">
                                                
                                            
                                           


                                                    <img class="w-100 rounded-top " id="imagePreview3" alt="" style="height:250px;width:200px;" src="html/lms/properties_documents/blank.jpg">
                                        
                                              
                                            
                                           
                                                </div>
                                       

                                                        <input type="file" id="imageInput3" accept="image/*"  class=" pt-4 form-control " name="noc" >
                                                    </div>
                                                </div>




                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label" for="email">Property Tax Receipts</label>


                                                     
                                               
                                            <div class="gallery card ">
                                                
                                            
                                           


                                                    <img class="w-100 rounded-top " id="imagePreview4" alt="" style="height:250px;width:200px;" src="html/lms/properties_documents/blank.jpg">
                                        
                                              
                                            
                                           
                                                </div>
                                       

                                                        <input type="file" id="imageInput4" accept="image/*"  class=" pt-4 form-control " name="property_tax_receipts" >
                                                    </div>
                                                </div>






                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label" for="email">Power of Attorney (if applicable)</label>


                                                     
                                               
                                            <div class="gallery card ">
                                                
                                            
                                           


                                                    <img class="w-100 rounded-top " id="imagePreview5" alt="" style="height:250px;width:200px;" src="html/lms/properties_documents/blank.jpg">
                                        
                                              
                                            
                                           
                                                </div>
                                       

                                                        <input type="file" id="imageInput5" accept="image/*"  class=" pt-4 form-control " name="power_of_attorney" >
                                                    </div>
                                                </div>






                                               




                <div class="col-md-12 mt-3">
                    <button type="submit" name="add_property" class="btn btn-block btn-lg btn-info">Property Registered</button>
                </div>
            </div>
        </div>
    </div>
</form>


              </div>
              <!--.nk-block -->                       



                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap, text-center">
                            <div class="nk-footer-copyright"> &copy; 2023 Safe Heaven. All rights reserved</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- select region modal -->


    


    <div class="modal fade" tabindex="-1" role="dialog" id="region">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <a href="html/under_const/index.html" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
                <div class="modal-body modal-body-md">
                    <h5 class="title mb-4">Select Your Country</h5>
                    <div class="nk-country-region">
                        <ul class="country-list text-center gy-2">
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/arg.png" alt="" class="country-flag">
                                    <span class="country-name">Argentina</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/aus.png" alt="" class="country-flag">
                                    <span class="country-name">Australia</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/bangladesh.png" alt="" class="country-flag">
                                    <span class="country-name">Bangladesh</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/canada.png" alt="" class="country-flag">
                                    <span class="country-name">Canada <small>(English)</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/china.png" alt="" class="country-flag">
                                    <span class="country-name">Centrafricaine</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/china.png" alt="" class="country-flag">
                                    <span class="country-name">China</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/french.png" alt="" class="country-flag">
                                    <span class="country-name">France</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/germany.png" alt="" class="country-flag">
                                    <span class="country-name">Germany</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/iran.png" alt="" class="country-flag">
                                    <span class="country-name">Iran</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/italy.png" alt="" class="country-flag">
                                    <span class="country-name">Italy</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/mexico.png" alt="" class="country-flag">
                                    <span class="country-name">México</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/philipine.png" alt="" class="country-flag">
                                    <span class="country-name">Philippines</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/portugal.png" alt="" class="country-flag">
                                    <span class="country-name">Portugal</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/s-africa.png" alt="" class="country-flag">
                                    <span class="country-name">South Africa</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/spanish.png" alt="" class="country-flag">
                                    <span class="country-name">Spain</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/switzerland.png" alt="" class="country-flag">
                                    <span class="country-name">Switzerland</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/uk.png" alt="" class="country-flag">
                                    <span class="country-name">United Kingdom</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/english.png" alt="" class="country-flag">
                                    <span class="country-name">United State</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div><!-- .modal-content -->
        </div><!-- .modla-dialog -->
    </div><!-- .modal -->
    <!-- JavaScript -->
    <script src="./assets/js/bundle.js?ver=3.0.3"></script>
    <script src="./assets/js/scripts.js?ver=3.0.3"></script><script src="html/lms/datetime.js"></script>

    <script>


document.getElementById('imageInput1').addEventListener('change', function (event) {
        // Get the selected file
        const file = event.target.files[0];

        // Check if a file is selected
        if (file) {
            // Create a FileReader object
            const reader = new FileReader();

            // Set up the onload event handler
            reader.onload = function (e) {
                // Set the source of the image preview to the result of the FileReader
                document.getElementById('imagePreview1').src = e.target.result;
            };

            // Read the file as a data URL
            reader.readAsDataURL(file);
        }
    });





    
document.getElementById('imageInput2').addEventListener('change', function (event) {
        // Get the selected file
        const file = event.target.files[0];

        // Check if a file is selected
        if (file) {
            // Create a FileReader object
            const reader = new FileReader();

            // Set up the onload event handler
            reader.onload = function (e) {
                // Set the source of the image preview to the result of the FileReader
                document.getElementById('imagePreview2').src = e.target.result;
            };

            // Read the file as a data URL
            reader.readAsDataURL(file);
        }
    });


    
document.getElementById('imageInput3').addEventListener('change', function (event) {
        // Get the selected file
        const file = event.target.files[0];

        // Check if a file is selected
        if (file) {
            // Create a FileReader object
            const reader = new FileReader();

            // Set up the onload event handler
            reader.onload = function (e) {
                // Set the source of the image preview to the result of the FileReader
                document.getElementById('imagePreview3').src = e.target.result;
            };

            // Read the file as a data URL
            reader.readAsDataURL(file);
        }
    });

    
document.getElementById('imageInput4').addEventListener('change', function (event) {
        // Get the selected file
        const file = event.target.files[0];

        // Check if a file is selected
        if (file) {
            // Create a FileReader object
            const reader = new FileReader();

            // Set up the onload event handler
            reader.onload = function (e) {
                // Set the source of the image preview to the result of the FileReader
                document.getElementById('imagePreview4').src = e.target.result;
            };

            // Read the file as a data URL
            reader.readAsDataURL(file);
        }
    });


    
document.getElementById('imageInput5').addEventListener('change', function (event) {
        // Get the selected file
        const file = event.target.files[0];

        // Check if a file is selected
        if (file) {
            // Create a FileReader object
            const reader = new FileReader();

            // Set up the onload event handler
            reader.onload = function (e) {
                // Set the source of the image preview to the result of the FileReader
                document.getElementById('imagePreview5').src = e.target.result;
            };

            // Read the file as a data URL
            reader.readAsDataURL(file);
        }
    });

    </script>


  
</body>

</html>