<?php
// Include the header file
include 'header.php';

// Include the database connection file
include 'connect.php';

// Function to display property details
function displayPropertyDetails($propertyDetails)
{
    ?>
    <!-- HTML markup to display property details -->

    <div class="container mt-4">
        <h3 class="mb-4">Property Details</h3>
        <h3 class="mb-4">Property Details</h3>

        <!-- Owner Details -->
        <div class="card mb-4">
            <div class="card-body">
            <h5 class="bg-dark text-white p-1 text-center">Owner Details</h5>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>Owner ID:</strong> <?php echo $propertyDetails['property_code']; ?></li>
                    <li class="list-group-item"><strong>Owner Name:</strong> <?php echo $propertyDetails['owner_name']; ?></li>
                    <li class="list-group-item"><strong>Phone Number:</strong> <?php echo $propertyDetails['phone_number']; ?></li>
                    <li class="list-group-item"><strong>CNIC:</strong> <?php echo $propertyDetails['cnic']; ?></li>
                    <li class="list-group-item"><strong>Status Property :</strong>   <a    class=" btn  " >   <span class="dot bg-success d-sm-none"></span>
                                               <span class="badge badge-sm badge-dot has-bg bg-success d-none d-sm-inline-flex  "     >Approved</span></a></li>
                </ul>
            </div>
        </div>

        <!-- Property Details -->
        <div class="card mb-4">
            <div class="card-body">
            <h5 class="bg-dark text-white p-1 text-center">Property Details</h5>
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><strong>Property Type:</strong> <?php echo $propertyDetails['property_type']; ?></li>
                            <li class="list-group-item"><strong>City:</strong> <?php echo $propertyDetails['city']; ?></li>
                            <li class="list-group-item"><strong>Property Address:</strong> <?php echo $propertyDetails['property_address']; ?></li>
                            <li class="list-group-item"><strong>Property Size:</strong> <?php echo $propertyDetails['property_size']; ?></li>
                            <li class="list-group-item"><strong>Year of Construction:</strong> <?php echo $propertyDetails['year_of_construction']; ?></li>
                            <li class="list-group-item"><strong>Property Description:</strong> <?php echo $propertyDetails['property_description']; ?></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>


        <!-- Property Features -->
        <div class="card mb-4">
            <div class="card-body">
            <h5 class="bg-dark text-white p-1 text-center">Property Features</h5>
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group list-group-flush">
                            
                            <li class="list-group-item"><strong>No of Bedrooms:</strong> <?php echo $propertyDetails['bedrooms']; ?></li>
                            <li class="list-group-item"><strong>No of Bathrooms:</strong> <?php echo $propertyDetails['bathrooms']; ?></li>
                            <li class="list-group-item"><strong>Amenities:</strong> <?php echo $propertyDetails['amenities']; ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>







        <!-- Upload Documents -->
        <div class="card mb-4">
            <div class="card-body">
            <h5 class="bg-dark text-white p-1 text-center">Upload Documents (Jpg, png etc)</h5></br>
                <div class="row">
                    <?php
                    $documentSections = ['sale_deed', 'title_deed', 'noc', 'property_tax_receipts', 'power_of_attorney'];

                    foreach ($documentSections as $section) {
                        ?>
                        <div class="col-md-6 mb-4">
                            <h6 class="card-subtitle mb-2 text-muted"><?php echo ucfirst(str_replace('_', ' ', $section)); ?></h6>
                            <img class="w-100 rounded-top" src="html/lms/properties_documents/<?php echo $propertyDetails[$section]; ?>" alt="">
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <!-- Back button -->
        <a href="html/lms/property_data.php" class="btn btn-info">Back to Property Records</a>
    </div>
    <?php
}

if (isset($_GET['property_id'])) {
    $property_id = $_GET['property_id'];

    try {
        $stmt = $conn->prepare("SELECT * FROM properties_data WHERE property_code = :property_code");
        $stmt->bindParam(':property_code', $property_id);
        $stmt->execute();
        $propertyDetails = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if property details were found
        if ($propertyDetails) {
            displayPropertyDetails($propertyDetails);
        } else {
            echo "Property not found.";
        }
    } catch (PDOException $e) {
        echo "Error fetching property details: " . $e->getMessage();
    }
}
?>
