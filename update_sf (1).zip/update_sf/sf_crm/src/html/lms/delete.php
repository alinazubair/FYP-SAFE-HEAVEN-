<?php



include 'connect.php';

 

 
	if(isset($_GET['action'])){
		$action = $_GET['action'];
	}
 
	
 
	if($action == 'properties_delete'){
		$id = $_POST['id'];
		$output = array();
		$sql = "DELETE FROM properties_data WHERE id = '$id'";
		if($sq_conn->query($sql)){
			$output['status'] = 'success';
			$output['message'] = 'Property deleted successfully';
		}
		else{
			$output['status'] = 'error';
			$output['message'] = 'Something went wrong in deleting the member';
		}
 
		echo json_encode($output);
 
	}
?>

 