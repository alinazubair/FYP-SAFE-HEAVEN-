<?php



include 'header.php';
?>
                <!-- main header @e -->
               
                <!-- content @s -->
                <!-- Content Section for Viewing Property Records -->
<!-- Content Section for Viewing Property Records -->
<div class="nk-content">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block">
                    <div class="card">
                        <div class="card-inner">
                            <div class="row gy-4">
                                <div class="col-md-12">
                                    <h3 class="nk-block-title page-title">View Property Records</h3>
                                </div>

                                <!-- Search Bar -->
                                <div class="col-md-3 mb-1">
                                 <div class="input-group">
                                   <input type="text" class="form-control" placeholder="Type in to Search">
                                   <button class="btn btn-info" type="button">Search</button>
                                 </div>
                                 </div>
                            <div class="col-md-4 mb-1">
                        </div>

                                <!-- End of Search Bar -->

                                <!-- Table for Property Records -->
                                <div class="col-md-12">
                                    <table class="table table-bordered text-center">
                                        <thead>
                                            <tr>
                                                <th>Property ID</th>
                                                <th>Owner Name</th>
                                                <th>City</th>
                                                <th>Property Type</th>
                                                <th>View Records</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Sample Property Records -->
                                            <tr>
                                                <td>90977</td>
                                                <td>John Doe</td>
                                                <td>Karachi</td>
                                                <td>Residential</td>
                                                <td>
                                                    <a href="view_property.php?id=1" class="btn btn-info">View Details</a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>81912</td>
                                                <td>Jane Smith</td>
                                                <td>Lahore</td>
                                                <td>Commercial</td>
                                                <td>
                                                    <a href="view_property.php?id=2" class="btn btn-info">View Details</a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>54356</td>
                                                <td>Michael Brown</td>
                                                <td>Multan</td>
                                                <td>Residential</td>
                                                <td>
                                                    <a href="view_property.php?id=5" class="btn btn-info">View Details</a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>33476</td>
                                                <td>Robert Johnson</td>
                                                <td>Islamabad</td>
                                                <td>Industrial</td>
                                                <td>
                                                    <a href="view_property.php?id=3" class="btn btn-info">View Details</a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>45005</td>
                                                <td>Sarah Williams</td>
                                                <td>Faisalabad</td>
                                                <td>Vacant</td>
                                                <td>
                                                    <a href="view_property.php?id=4" class="btn btn-info">View Details</a>
                                                </td>
                                            </tr>
                                            <!-- End of Sample Property Records -->

                                            <!-- Repeat the above block for each property record -->
                                        </tbody>
                                    </table>

                                    <!-- Navigation Options -->
                                    <div class="col-md-12 text-left mt-3">
                                        <a href="#" class="btn btn-info">Prev</a>
                                        <a href="#" class="btn btn-info">Next</a>
                                    </div>
                                    <!-- End of Navigation Options -->
                                </div>
                                <!-- End of Table for Property Records -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Content Section for Viewing Property Records -->


                <!-- content @e -->
                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap, text-center">
                            <div class="nk-footer-copyright"> &copy; 2023 Safe Heaven. All rights reserved</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- select region modal -->


    


    <div class="modal fade" tabindex="-1" role="dialog" id="region">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <a href="html/under_const/index.html" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
                <div class="modal-body modal-body-md">
                    <h5 class="title mb-4">Select Your Country</h5>
                    <div class="nk-country-region">
                        <ul class="country-list text-center gy-2">
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/arg.png" alt="" class="country-flag">
                                    <span class="country-name">Argentina</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/aus.png" alt="" class="country-flag">
                                    <span class="country-name">Australia</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/bangladesh.png" alt="" class="country-flag">
                                    <span class="country-name">Bangladesh</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/canada.png" alt="" class="country-flag">
                                    <span class="country-name">Canada <small>(English)</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/china.png" alt="" class="country-flag">
                                    <span class="country-name">Centrafricaine</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/china.png" alt="" class="country-flag">
                                    <span class="country-name">China</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/french.png" alt="" class="country-flag">
                                    <span class="country-name">France</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/germany.png" alt="" class="country-flag">
                                    <span class="country-name">Germany</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/iran.png" alt="" class="country-flag">
                                    <span class="country-name">Iran</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/italy.png" alt="" class="country-flag">
                                    <span class="country-name">Italy</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/mexico.png" alt="" class="country-flag">
                                    <span class="country-name">México</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/philipine.png" alt="" class="country-flag">
                                    <span class="country-name">Philippines</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/portugal.png" alt="" class="country-flag">
                                    <span class="country-name">Portugal</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/s-africa.png" alt="" class="country-flag">
                                    <span class="country-name">South Africa</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/spanish.png" alt="" class="country-flag">
                                    <span class="country-name">Spain</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/switzerland.png" alt="" class="country-flag">
                                    <span class="country-name">Switzerland</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/uk.png" alt="" class="country-flag">
                                    <span class="country-name">United Kingdom</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/english.png" alt="" class="country-flag">
                                    <span class="country-name">United State</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div><!-- .modal-content -->
        </div><!-- .modla-dialog -->
    </div><!-- .modal -->
    <!-- JavaScript -->
    <script src="./assets/js/bundle.js?ver=3.0.3"></script>
    <script src="./assets/js/scripts.js?ver=3.0.3"></script><script src="html/lms/datetime.js"></script>

  
</body>

</html>