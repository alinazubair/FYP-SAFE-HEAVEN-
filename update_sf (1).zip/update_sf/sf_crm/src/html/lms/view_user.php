<?php
include 'connect.php';

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Fetch user details from the database
    $stmt = $conn->prepare("SELECT * FROM properties_data WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    $userDetails = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
