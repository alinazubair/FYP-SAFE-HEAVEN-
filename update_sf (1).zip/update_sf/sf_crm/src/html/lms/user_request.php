<?php
include 'header.php';
include 'connect.php';

// Fetch user details from the database based on the user's session
try {
    $stmt = $conn->prepare("SELECT owner_name, property_code FROM properties_data WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $_SESSION['user_id']);
    $stmt->execute();
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error fetching user details: " . $e->getMessage();
}

// Initialize $propertyRequests as an empty array to avoid undefined variable warnings
$propertyRequests = [];

// Check if property submission requests are available
if (isset($propertyRequests) && is_array($propertyRequests) && count($propertyRequests) > 0) {
    // Display property requests
    foreach ($propertyRequests as $request) {
        // Check the status of each request
        $status = $request['status'];

        // Display the appropriate message based on the status
        if ($status == 'approved') {
            echo "Request Approved for Property Code: " . $request['property_code'];
        } else {
            echo "Request Pending for Property Code: " . $request['property_code'];
        }

        // You can add more details as needed
        // ...

        echo "<br>";
    }
} else {
    // Display a message indicating no property requests
    echo "No property requests available.";
}
?>

<div class="nk-content">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between g-3">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">Property Submission Request</h3>
                        </div>
                    </div>
                </div>

                <!-- Display message to inform user about approval/rejection -->
                <?php
                if (isset($_GET['status'])) {
                    if ($_GET['status'] == 'approved') {
                        echo '<div class="alert alert-success">Property submission approved successfully.</div>';
                    } elseif ($_GET['status'] == 'rejected') {
                        echo '<div class="alert alert-danger">Property submission rejected.</div>';
                    }
                }
                ?>

                <!-- Form to submit property details -->
                <!-- Use the same form as add_property.php with a submit button -->
            </div>
        </div>
    </div>
</div>

<?php ?>
