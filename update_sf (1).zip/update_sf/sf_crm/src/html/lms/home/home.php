<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <!-- Add your CSS stylesheets or link to a CDN here -->
</head>

<body>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6">
                <h1>Welcome to Our Website</h1>
                <p>This is the home page content. You can add more sections and content as needed.</p>
            </div>
            <div class="col-md-6 text-end">
                <div class="mt-2">
                    <?php
                    // Check if the user is logged in and display appropriate buttons
                    if (isset($_SESSION['user_id'])) {
                        echo '<a href="logout.php" class="btn btn-danger">Logout</a>';
                    } else {
                        echo '<a href="login.php" class="btn btn-primary">Login</a>';
                        echo '<a href="signup.php" class="btn btn-success ms-2">Sign Up</a>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2024 Your Website. All rights reserved.</p>
    </footer>

    <!-- Add your additional scripts here -->

</body>

</html>
