<?php
include 'header.php';
?>

<div class="nk-content">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="content-page wide-md m-auto">
                    <div class="nk-block-head nk-block-head-lg wide-xs mx-auto">
                        <div class="nk-block-head-content text-center">
                            <h2 class="nk-block-title fw-normal">Query Area</h2>
                            <div class="nk-block-des"></div>
                        </div>
                    </div>

                    <div class="card card-bordered card-preview">
                        <div class="card-inner">
                            <div class="example-alerts">
                                <div class="gy-4">

                                    <?php

                                    include 'connect.php';
                                    // Check if the form is submitted
                                    // if (isset($_POST['POST']) && $_POST['POST'] == "add_property") {

                                        $username = $_POST["username"];
                                        // Retrieve form data
                                        $email = $_POST["email"];
                                        $ac_feedback = $_POST["ac_feedback"];
                                        

                                        

                                        // Database connection (replace with your database credentials)
                                        // Insert data into the database
                                    // Prepare the SQL statement
                                    $sql = "INSERT INTO users 
                                    (username, email, ac_feedback, user)
                                    VALUES 
                                    (:username, :email, :ac_feedback, :user)";
                                
                                // Prepare the PDO statement
                                $stmt = $conn->prepare($sql);
                                
                                // Bind parameters
                                $stmt->bindParam(':username', $username);
                                $stmt->bindParam(':email', $email);
                                $stmt->bindParam('ac_feedback', $ac_feedback); 
                                
                                $stmt->bindParam(':user', $user);
                                
                                // Execute the PDO statement
                                if ($stmt->execute()) {
                                    // Success
                                    ?>
                                    <div class="example-alert">
                                        <div class="alert alert-success alert-icon">
                                            <em class="icon ni ni-check-circle"></em> <strong> Feedback submitted Successfully</strong><a href="html/lms/feedback_support.php"> < GO Back. </a>
                                        </div>
                                    </div>
                                <?php
                                } else {
                                    ?>
                                    <div class="example-alert">
                                        <div class="alert alert-fill alert-danger alert-icon">
                                            <em class="icon ni ni-cross-circle"></em> <strong>Update failed</strong>! There are some technical issues.
                                        </div>
                                    </div>
                                <?php
                                }
                                ?>
                                
                                </div>
                            </div>
                        </div>
                    </div><!-- .card-preview -->
                </div><!-- .content-page -->
            </div>
        </div>
    </div>
</div>

<!-- footer -->
<div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright">
                &copy; 2022 Deniss. Developed by <a href="https://designsexpertise.com/" target="_blank">DESIGNS EXPERTISE.</a>
            </div>
            <div class="nk-footer-links">
                <ul class="nav nav-sm">
                    <li class="nav-item dropup">
                        <a href="html/under_const/index.html" class="dropdown-toggle dropdown-indicator has-indicator nav-link text-base" data-bs-toggle="dropdown" data-offset="0,10"><span>English</span></a>
                        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                            <ul class="language-list">
                                <!-- Language list items go here -->
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a data-bs-toggle="modal" href="#region" class="nav-link"><em class="icon ni ni-globe"></em><span class="ms-1">Select Region</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- footer -->

<!-- select region modal -->
<div class="modal fade" tabindex="-1" role="dialog" id="region">
    <!-- Modal content goes here -->
</div>

<!-- JavaScript -->
<script src="./assets/js/bundle.js?ver=3.0.3"></script>
<script src="./assets/js/scripts.js?ver=3.0.3"></script>
<script src="html/lms/datetime.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</body>
</html>
