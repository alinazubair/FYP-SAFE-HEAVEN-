-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2024 at 08:33 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `safe_heaven`
--

-- --------------------------------------------------------

--
-- Table structure for table `properties_data`
--

CREATE TABLE `properties_data` (
  `id` int(11) NOT NULL,
  `owner_name` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `cnic` varchar(15) NOT NULL,
  `property_type` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `property_address` varchar(255) NOT NULL,
  `property_size` varchar(50) NOT NULL,
  `property_description` text NOT NULL,
  `year_of_construction` date NOT NULL,
  `bedrooms` int(11) NOT NULL,
  `bathrooms` int(11) NOT NULL,
  `amenities` varchar(255) NOT NULL,
  `sale_deed` varchar(255) NOT NULL,
  `title_deed` varchar(255) NOT NULL,
  `noc` varchar(255) NOT NULL,
  `property_tax_receipts` varchar(255) NOT NULL,
  `power_of_attorney` varchar(255) NOT NULL,
  `property_code` varchar(50) NOT NULL,
  `user` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `status` varchar(50) NOT NULL DEFAULT 'unpaid',
  `submission_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `document_type` varchar(255) NOT NULL,
  `document_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties_data`
--

INSERT INTO `properties_data` (`id`, `owner_name`, `phone_number`, `cnic`, `property_type`, `city`, `property_address`, `property_size`, `property_description`, `year_of_construction`, `bedrooms`, `bathrooms`, `amenities`, `sale_deed`, `title_deed`, `noc`, `property_tax_receipts`, `power_of_attorney`, `property_code`, `user`, `feedback`, `date`, `status`, `submission_time`, `document_type`, `document_path`) VALUES
(7, 'Ramsha', '021312312312312', '441231231212121', 'Industrial', 'Karachi', 'sadar karachi', '50', 'ksjdaskld sadjsalkdjas;kd;laskd;', '2020-07-22', 5, 6, '0', 'p1.jpg', 'p2.jpg', 'p3.jpg', 'p4.jpg', 'p5.jpg', '47733', '', 'dilways is pretty', '2024-01-22 16:48:03.186549', 'approved', '2024-01-25 22:08:24', '', ''),
(8, 'akash', '0301222', '44444444', 'Commercial', 'Karachi', 'defence view karachi', '100', 'sdasdasdmasdkasm', '2023-01-20', 7, 8, '0', 'p1.jpg', 'p2.jpg', 'p3.jpg', 'p4.jpg', 'p5.jpg', '22862', '', 'hello world', '2024-01-22 16:57:43.585364', 'paid', '2024-01-25 22:08:24', '', ''),
(11, 'Sunny RAJ', '210983471', '444444444414323', 'Residential', 'Karachi', 'north karachi', '40', 'asdkjasklj', '2024-01-13', 5, 7, '0', '', '', '', '', '', '93665', 'sunny@gmail.com', '', '2024-01-24 02:19:29.348570', 'paid', '2024-01-25 22:08:24', '', ''),
(14, 'Aleena', '0123123123123', '444444444444555', 'Industrial', 'Islamabad', 'sadar karachi', '50', 'sadasdasdasdad', '2024-01-25', 5, 6, '0', 'p1.jpg', 'p2.jpg', 'p3.jpg', 'p4.jpg', 'p5.jpg', '70624', 'admin@gmail.com', '', '2024-01-25 15:20:46.151633', 'rejected', '2024-01-25 22:08:24', '', ''),
(16, 'asdasd', '', '', 'Residential', 'Karachi', '', '', '', '0000-00-00', 0, 0, '0', '', '', '', '', '', '25929', 'admin@gmail.com', '', '2024-01-25 15:30:42.875439', 'approved', '2024-01-25 22:08:24', '', ''),
(17, 'ali', '', '', 'Residential', 'Karachi', '', '', '', '0000-00-00', 0, 0, '0', '', '', '', '', '', '95614', 'admin@gmail.com', '', '2024-01-25 15:38:04.063223', 'rejected', '2024-01-25 22:08:24', '', ''),
(19, 'sabir', '', '', 'Residential', 'Karachi', '', '', '', '0000-00-00', 0, 0, '0', '', '', '', '', '', '64078', 'root', '', '2024-01-26 01:59:27.091266', 'approved', '2024-01-25 22:08:24', '', ''),
(20, 'sosso', '', '', 'Residential', 'Karachi', '', '', '', '0000-00-00', 0, 0, 'garden', '', '', '', '', '', '57703', 'root', '', '2024-01-26 02:11:36.629780', 'approved', '2024-01-25 22:08:24', '', ''),
(21, 'Waqas', '01231231453', '44444474894444', 'Industrial', 'Karachi', 'north karachi pakistan', '50', 'sjdlkas ladkjasljdlask  sdlask', '2024-01-19', 5, 6, 'parking area', 'sale_deed.png', 'title_deed.png', 'noc.png', 'property_tax_receipts.png', 'power_of_attorney.png', '28843', 'root', 'your service is bad', '2024-01-26 02:22:10.695083', 'approved', '2024-01-25 22:08:24', '', ''),
(22, 'Aleena', '', '', 'Residential', 'Karachi', '', '', '', '0000-00-00', 0, 0, '', '', '', '', '', '', '45377', 'root', '', '2024-01-26 02:54:56.206971', 'unpaid', '2024-01-25 22:08:24', '', ''),
(23, 'asdas', '', '', 'Residential', 'Karachi', '', '', '', '0000-00-00', 0, 0, '', '', '', '', '', '', '25194', 'root', 'gggg', '2024-01-26 04:06:29.596660', 'approved', '2024-01-25 23:06:29', '', ''),
(24, 'AKASH', '', '', 'Residential', 'Karachi', '', '', '', '0000-00-00', 0, 0, '', '', '', '', '', '', '55101', 'root', '', '2024-01-27 15:15:27.336616', 'approved', '2024-01-27 10:15:27', '', ''),
(25, 'nazim ali binte dilawys', '031-034-9715', '455555555555', 'Residential', 'Karachi', '5000', '5000', 'fff', '2024-03-30', 555, 55, '55', '', '', '', '', '', '79913', 'root', '', '2024-03-14 11:18:26.595887', 'unpaid', '2024-03-14 06:18:26', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `public`
--

CREATE TABLE `public` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(250) DEFAULT NULL,
  `role` varchar(250) DEFAULT NULL,
  `profile` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `email` varchar(250) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `upload_image` varchar(25) NOT NULL,
  `state` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `ac_property` varchar(12) NOT NULL,
  `ac_security` varchar(10) NOT NULL,
  `ac_user_property` varchar(10) NOT NULL,
  `ac_verification` varchar(11) NOT NULL,
  `ac_alerts_notifications` varchar(11) NOT NULL,
  `ac_document` varchar(11) NOT NULL,
  `ac_feedback` varchar(11) NOT NULL,
  `ac_party_mang` varchar(11) NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT '0',
  `updatesystem` varchar(50) NOT NULL DEFAULT 'update',
  `date_time` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `role`, `profile`, `phone`, `email`, `password`, `upload_image`, `state`, `address`, `ac_property`, `ac_security`, `ac_user_property`, `ac_verification`, `ac_alerts_notifications`, `ac_document`, `ac_feedback`, `ac_party_mang`, `status`, `updatesystem`, `date_time`) VALUES
(93, 'Ramsha ', 'admin', 'upload/b-sm.jpg', '1234567899', 'admin@gmail.com', 'admin', '', 'Lahore', '', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'on', 'off', 'updated', '2022-09-20 17:07:41.636984'),
(187, 'Waqas Waqas', 'public', 'upload/222.jpg', 'nadir@gmail.com', 'wwwranawaqas02@gmail.com', '1234', '', 'Karachi', 'house no 776 sector 32/A zia colony korangi no 1 karachi.', '', '', '', '', '', '', '', '', '0', 'update', '2023-11-16 11:26:59.994983'),
(190, 'sunny', 'public', '', '', 'sunny@gmail.com', '1234', '', '', '', '', '', '', '', '', '', '', '', '0', 'update', '2024-01-25 09:28:54.781282'),
(191, 'Abdul Ali', 'public', '', '', 'abdulali@gmail.com', '1234', '', '', '', '', '', '', '', '', '', '', '', '0', 'update', '2024-01-25 20:44:50.581255'),
(192, 'Abdul Ali', 'public', '', '', 'abdulali@gmail.com', '1234', '', '', '', '', '', '', '', '', '', '', '', '0', 'update', '2024-01-25 20:45:01.821094');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `properties_data`
--
ALTER TABLE `properties_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `public`
--
ALTER TABLE `public`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `properties_data`
--
ALTER TABLE `properties_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `public`
--
ALTER TABLE `public`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=193;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
